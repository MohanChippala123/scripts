
#!/bin/bash

set -x
set -uo pipefail

# need root
if [ "$EUID" -ne 0 ]; then
  echo "run as root" >&2
  exit 1
fi

# get a number
ask_count() {
  while true; do
    read -rp "$1" count

    if echo "$count" | grep -Eq '^[1-9][0-9]*$'; then
      return
    fi

    echo "enter a number" >&2
  done
}

# check username
valid_name() {
  echo "$1" | grep -Eq '^[a-z_][a-z0-9_-]*\$?$'
}

# menu for all our features that we added
echo "pick one:"
echo "1 add"
echo "2 remove"
echo "3 users"
echo "4 groups"
echo "5 add to group"
echo "6 remove from group"

read -rp "pick: " choice

case "$choice" in
  1)
    ask_count "how many? "

    for ((i=1; i<=count; i++)); do
      read -rp "user $i: " username

      if ! valid_name "$username"; then
        echo "bad name"
        continue
      fi

      if id "$username" &>/dev/null; then
        echo "already exists: $username"
      else
        echo "adding: $username"

        if useradd -m "$username"; then
          echo "added: $username"
        fi
      fi
    done
    ;;

  2)
    ask_count "how many? "

    for ((i=1; i<=count; i++)); do
      read -rp "user $i: " username

      if ! id "$username" &>/dev/null; then
        echo "not found: $username"
        continue
      fi

      echo "removing: $username"

      if userdel -r "$username"; then
        echo "removed: $username"
      fi
    done
    ;;

  3)
    echo "users:"
    awk -F: '$3 >= 1000 && $3 != 65534 {print $1}' /etc/passwd
    ;;

  4)
    ask_count "how many? "

    for ((i=1; i<=count; i++)); do
      read -rp "user $i: " username

      if id "$username" &>/dev/null; then
        groups "$username"
      else
        echo "not found: $username"
      fi
    done
    ;;

  5)
    ask_count "how many? "

    for ((i=1; i<=count; i++)); do
      read -rp "user $i: " username

      if ! id "$username" &>/dev/null; then
        echo "not found: $username"
        continue
      fi

      read -rp "group: " groupname

      if getent group "$groupname" &>/dev/null; then
        if usermod -aG "$groupname" "$username"; then
          echo "added: $username to $groupname"
        fi
      else
        echo "not found: $groupname"
      fi
    done
    ;;

  6)
    ask_count "how many? "

    for ((i=1; i<=count; i++)); do
      read -rp "user $i: " username

      if ! id "$username" &>/dev/null; then
        echo "not found: $username"
        continue
      fi

      read -rp "group: " groupname

      if getent group "$groupname" &>/dev/null; then
        if gpasswd -d "$username" "$groupname"; then
          echo "removed: $username from $groupname"
        fi
      else
        echo "not found: $groupname"
      fi
    done
    ;;

  *)
    echo "pick 1-6"
    exit 1
    ;;
esac
