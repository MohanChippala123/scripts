
#!/bin/bash

# folders
home="/home"

# file types
types=(
mp3
flac
wav
ogg
mp4
mkv
avi
webm
iso
appimage
rom
)

# find files
echo "files:"

files=()

for type in "${types[@]}"; do

  while IFS= read -r -d '' file; do
    files+=("$file")
  done < <(
    find "$home" -type f \
    -iname "*.$type" \
    -print0 2>/dev/null
  )

done

# show results
num=1

for file in "${files[@]}"; do
  echo "$num) $file"
  num=$((num + 1))
done

if [ "${#files[@]}" -eq 0 ]; then
  echo "none"
fi

# delete files
echo ""
read -rp "delete? y/n: " answer

if [ "$answer" = "y" ]; then

  while true; do

    read -rp "number (0 to stop): " num

    if [ "$num" = "0" ]; then
      break
    fi

    if ! [[ "$num" =~ ^[0-9]+$ ]]; then
      echo "bad number"
      continue
    fi

    if [ "$num" -lt 1 ]; then
      echo "bad number"
      continue
    fi

    if [ "$num" -gt "${#files[@]}" ]; then
      echo "bad number"
      continue
    fi

    file="${files[$((num - 1))]}"

    if [ ! -f "$file" ]; then
      echo "not found"
      continue
    fi

    echo "$file"
    read -rp "sure? y/n: " sure

    if [ "$sure" = "y" ]; then
      rm -i -- "$file"
    fi

  done

fi

# app categories
echo ""
echo "apps:"

categories=(
Game
AudioVideo
Media
Audio
Video
)

folders=(
/usr/share/applications
/home/*/.local/share/applications
/var/lib/snapd/desktop/applications
/var/lib/flatpak/exports/share/applications
)

for cat in "${categories[@]}"; do

  echo "$cat"

  for folder in "${folders[@]}"; do

    if [ -d "$folder" ]; then
      grep -rl "Categories=.*$cat" "$folder" 2>/dev/null
    fi

  done

done

echo "done"
