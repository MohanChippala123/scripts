
#!/bin/bash

if [ "$EUID" -ne 0 ]; then
  echo "use sudo"
  exit 1
fi

# check passwords
echo "checking"

awk -F: '$2 == "" {print $1}' /etc/shadow

# install
if ! dpkg -s libpam-pwquality >/dev/null 2>&1; then
  apt-get install libpam-pwquality

  if [ "$?" -ne 0 ]; then
    echo "failed"
    exit 1
  fi
fi

# check pam
if ! grep -q pam_pwquality.so \
  /etc/pam.d/common-password; then
  echo "check pam"
  exit 1
fi

# backup
echo "backup"

cp /etc/login.defs /etc/login.defs.bak

mkdir -p /etc/security/pwquality.conf.d

file=/etc/security/pwquality.conf.d/99-cyber.conf

if [ -f "$file" ]; then
  cp "$file" "$file.bak"
fi

# password rules
echo "setting"

cat > "$file" <<EOF
minlen = 12
minclass = 4
dcredit = 0
ucredit = 0
lcredit = 0
ocredit = 0
enforcing = 1
EOF

# password age
sed -i '/^PASS_MAX_DAYS /d' /etc/login.defs
sed -i '/^PASS_MIN_DAYS /d' /etc/login.defs
sed -i '/^PASS_WARN_AGE /d' /etc/login.defs

echo "PASS_MAX_DAYS 90" >> /etc/login.defs
echo "PASS_MIN_DAYS 1" >> /etc/login.defs
echo "PASS_WARN_AGE 7" >> /etc/login.defs

# current users
echo "users"

while IFS=: read -r user pass uid rest; do

  if [ "$uid" -ge 1000 ]; then

    if [ "$uid" -ne 65534 ]; then
      echo "$user"

      chage -M 90 "$user"
      chage -m 1 "$user"
      chage -W 7 "$user"
    fi

  fi

done < /etc/passwd

echo "done"
