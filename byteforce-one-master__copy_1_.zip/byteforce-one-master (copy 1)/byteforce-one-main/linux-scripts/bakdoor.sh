
#!/bin/bash

if [ "$EUID" -ne 0 ]; then
  echo "use sudo"
  exit 1
fi

# stuff to look for
rules=(
  'nc[[:space:]].*-e'
  'nc[[:space:]].*--exec'
  'ncat[[:space:]].*-e'
  'ncat[[:space:]].*--exec'
  'netcat[[:space:]].*-e'
  'netcat[[:space:]].*--exec'
  'socat.*EXEC'
  'socat.*SYSTEM'
  '/dev/tcp/'
  'bash[[:space:]]+-i'
  'curl.*\|.*sh'
  'curl.*\|.*bash'
  'wget.*\|.*sh'
  'wget.*\|.*bash'
)

check_line() {
  for rule in "${rules[@]}"; do
    if echo "$1" | grep -Eiq "$rule"; then
      return 0
    fi
  done
  return 1
}

# check a file
check_file() {
  file="$1"
  [ -f "$file" ] || return

  while IFS= read -r line; do
    if check_line "$line"; then
      echo "check: $file"
      echo "$line"
    fi
  done < "$file"
}

# check python cron
check_python() {
  file="$1"
  [ -f "$file" ] || return

  while IFS= read -r line; do
    echo "$line" | grep -q 'python' || continue

    if echo "$line" | awk '
      $1=="*" && $2=="*" && $3=="*" &&
      $4=="*" && $5=="*" {exit 0}
      {exit 1}
    '; then
      echo "python every minute: $file"
      echo "$line"

      for word in $line; do
        case "$word" in
          /*.py)
            echo "folder: $(dirname "$word")"
            ;;
        esac
      done
    fi
  done < "$file"
}

# check processes
echo "processes:"

ps -eo pid=,args= | while IFS= read -r line; do
  echo "$line" | grep -q 'bakdoor.sh' && continue
  echo "$line" | grep -q 'grep -E' && continue

  if check_line "$line"; then
    echo "check: $line"
  fi
done

# user cron jobs
echo "cron:"

if command -v crontab >/dev/null 2>&1; then
  while IFS=: read -r user rest; do
    file=$(mktemp)

    crontab -u "$user" -l > "$file" 2>/dev/null

    check_file "$file"
    check_python "$file"

    rm -f "$file"
  done < /etc/passwd
fi

# system cron jobs
for file in /etc/crontab /etc/cron.d/*; do
  check_file "$file"
  check_python "$file"
done

# other cron scripts
for file in /etc/cron.hourly/* /etc/cron.daily/*; do
  check_file "$file"
done

# ssh keys
echo "ssh:"

for file in /root/.ssh/authorized_keys /home/*/.ssh/authorized_keys; do
  if [ -f "$file" ]; then
    echo "check: $file"
    ls -l "$file"
  fi
done

# startup files
echo "startup:"

for file in /root/.bashrc /root/.profile /home/*/.bashrc /home/*/.profile; do
  check_file "$file"
done

# extra root users
echo "root users:"

awk -F: '$3 == 0 && $1 != "root" {print $1}' /etc/passwd

echo "done"
