
#!/bin/bash

tools=(
nmap
wireshark
john
hydra
medusa
nikto
netcat
ettercap
ophcrack
kismet
logkeys
hashcat
metasploit-framework
aircrack-ng
yersinia
airgeddon
amass
arp-scan
bettercap
bloodhound
burpsuite
cewl
crackmapexec
crunch
dirb
dirbuster
dnsrecon
dsniff
ettercap-text-only
ffuf
fierce
gobuster
hping3
impacket-scripts
maltego
masscan
mimikatz
ncrack
netexec
netsniff-ng
pixiewps
powersploit
reaver
recon-ng
responder
sqlmap
tcpdump
theharvester
tshark
unicornscan
wfuzz
wifite
wpscan
zaproxy
pdfcrack
pyrit
rarcrack
sipcrack
)

if [ "$EUID" -ne 0 ]; then
  echo "use sudo"
  exit 1
fi

echo "checking"

for tool in "${tools[@]}"; do

  status=$(dpkg-query -W \
    -f='${Status}' "$tool" 2>/dev/null)

  if [ "$status" = "install ok installed" ]; then

    echo "found $tool"
    read -rp "delete? y/n: " answer

    if [ "$answer" = "y" ]; then

      apt-get -s remove "$tool"

      read -rp "sure? y/n: " confirm

      if [ "$confirm" = "y" ]; then
        apt-get remove "$tool"
      fi

    fi

  fi

done

echo "done"
#found all these tools from this one github