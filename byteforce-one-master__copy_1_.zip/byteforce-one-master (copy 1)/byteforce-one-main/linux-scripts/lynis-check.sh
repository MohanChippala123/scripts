#!/usr/bin/env bash
set -x
set -uo pipefail

if [ "$EUID" -ne 0 ]; then
  echo "run as root"
  exit 1
fi

sudo apt install lynis
sudo apt update && upgrade

sudo lynis audit system -Q --warnings-only --no-colors > ~/lynis_warnings.txt
echo "the audit results are at ~/lynis_warnings.txt"