
#!/bin/bash

if [ "$EUID" -ne 0 ]; then
  echo "use sudo"
  exit 1
fi

echo "checking"

words=(
"/tmp/"
"/var/tmp/"
"/dev/shm/"
"/dev/tcp/"
"nc -e"
"ncat -e"
"socat"
"python3 /usr/share/"
"python /usr/share/"
)

check() {
  for word in "${words[@]}"; do
    if echo "$1" | grep -Fqi "$word"; then
      return 0
    fi
  done

  return 1
}

# services
echo "services:"

systemctl list-unit-files \
  --type=service \
  --no-legend |
while read -r service rest; do

  cmd=$(systemctl show "$service" \
    -p ExecStart 2>/dev/null)

  if check "$cmd"; then
    echo "check: $service"
    echo "$cmd"
  fi

done

# processes
echo "scripts:"

ps -eo pid=,args= |
while read -r pid cmd; do

  if check "$cmd"; then
    echo "$pid $cmd"
  fi

done

# cron
echo "cron:"

grep -Rin "python" /etc/cron* 2>/dev/null
grep -Rin "/dev/tcp/" /etc/cron* 2>/dev/null

# failed services
echo "failed:"

systemctl list-units \
  --type=service \
  --state=failed \
  --no-pager

# stop a process
echo ""
read -rp "stop a process? y/n: " answer

if [ "$answer" = "y" ]; then

  read -rp "pid: " pid

  if ! [[ "$pid" =~ ^[0-9]+$ ]]; then
    echo "bad pid"
    exit 1
  fi

  if [ "$pid" -le 1 ]; then
    echo "bad pid"
    exit 1
  fi

  ps -p "$pid" -o pid=,args=

  if [ "$?" -ne 0 ]; then
    echo "not found"
    exit 1
  fi

  read -rp "sure? y/n: " sure

  if [ "$sure" = "y" ]; then
    kill "$pid"
    echo "sent stop"
  fi

fi

# python backdoor
file="/usr/share/zod/kneelB4zod.py"

if [ -f "$file" ]; then

  echo ""
  echo "found: $file"

  read -rp "disable cron? y/n: " answer

  if [ "$answer" = "y" ]; then

    cp /etc/crontab /etc/crontab.bak

    sed -i \
      '\|/usr/share/zod/kneelB4zod.py|s|^|# |' \
      /etc/crontab

    echo "done"
  fi

  read -rp "stop it? y/n: " answer

  if [ "$answer" = "y" ]; then

    pids=$(pgrep -f \
      '[/]usr/share/zod/kneelB4zod.py')

    for pid in $pids; do
      kill "$pid"
    done

    echo "done"
  fi

  read -rp "delete file? y/n: " answer

  if [ "$answer" = "y" ]; then
    rm -i -- "$file"
  fi

fi

echo "done"
#Mohan@123@Mohan@123 pswd for chowe