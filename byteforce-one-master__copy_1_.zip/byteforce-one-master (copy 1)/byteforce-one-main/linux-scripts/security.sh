
    
  
#!/bin/bash

# run as root
if [ "$EUID" != 0 ]; then
    sudo bash "$0" "$@"
    exit
fi

# stuff to look for
# these can show up in safe programs too
pat='(/dev/tcp/|bash -i|sh -i|nc .* -e |ncat .* -e |netcat .* -e |socat.*EXEC|socat.*SYSTEM|curl.*\|.*sh|wget.*\|.*sh|python.*socket|python.*pty)'

echo "checking stuff"

# check processes
echo "processes"
ps -eo pid=,args= > /tmp/bakdoor-procs.txt

grep -Ei "$pat" /tmp/bakdoor-procs.txt > /tmp/bakdoor-hits.txt

if [ -s /tmp/bakdoor-hits.txt ]; then
    while read -r pid command; do
        # don't stop this script
        if [ "$pid" = "$$" ]; then
            continue
        fi

        # sometimes the script itself shows up
        if echo "$command" | grep -q 'security_beginner_full.sh'; then
            continue
        fi

        echo "$pid $command"
        echo "kill it? y/n"
        read -r ans < /dev/tty

        if [ "$ans" = "y" ]; then
            kill "$pid" 2>/dev/null
            echo "killed"
        fi
    done < /tmp/bakdoor-hits.txt
else
    echo "nothing found"
fi

# check system cron
echo "cron"
for file in /etc/crontab /etc/cron.d/*; do
    if [ -f "$file" ]; then
        if grep -Ein "$pat" "$file"; then
            echo "$file"
            echo "disable these? y/n"
            read -r ans < /dev/tty

            if [ "$ans" = "y" ]; then
                cp -p "$file" "$file.bak"
                # use ~ because the pattern has / in it
                sed -i -E "\~$pat~s~^~# disabled ~" "$file"
                echo "disabled"
            fi
        fi
    fi
done

# check each user's cron
echo "user cron"
for user in $(cut -d: -f1 /etc/passwd); do
    crontab -u "$user" -l > /tmp/bakdoor-cron.txt 2>/dev/null

    if grep -Ein "$pat" /tmp/bakdoor-cron.txt; then
        echo "$user"
        echo "disable these? y/n"
        read -r ans < /dev/tty

        if [ "$ans" = "y" ]; then
            cp /tmp/bakdoor-cron.txt "/tmp/bakdoor-$user.bak"
            sed -i -E "\~$pat~s~^~# disabled ~" /tmp/bakdoor-cron.txt
            crontab -u "$user" /tmp/bakdoor-cron.txt
            echo "disabled"
        fi
    fi
done

# check files that run on login or startup
echo "startup"
for file in /root/.bashrc /root/.profile /home/*/.bashrc /home/*/.profile /etc/rc.local; do
    if [ -f "$file" ]; then
        if grep -Ein "$pat" "$file"; then
            echo "$file"
            echo "disable these? y/n"
            read -r ans < /dev/tty

            if [ "$ans" = "y" ]; then
                cp -p "$file" "$file.bak"
                sed -i -E "\~$pat~s~^~# disabled ~" "$file"
                echo "disabled"

