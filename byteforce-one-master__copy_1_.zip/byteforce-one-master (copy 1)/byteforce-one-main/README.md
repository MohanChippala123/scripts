# Byteforce One

## Changelog
- Added index.html
- Added linux-scripts.html
- Added linux-checklist.html
- Added linux-scripts folder containing
    - Added linux-hacking-tools.sh
    - Added media.sh
    - Added ubuntu-nopasswd-users.sh
    - ubuntu-user-management.sh
- Added bakdoor.sh & sus-services.sh to linux-scripts/
- Updated style elements in index.html, linux-scripts.html, and ubuntu-checklist.html

## Roadmap
- [x] Linux checklist
- [x] Script for ubuntu user management
- [x] Script for ubuntu hacking tool searching
- [x] Script for ubuntu media searching
- [x] Script to find users with no password on ubuntu
- [x] Script to find suspicious services on ubuntu
- [x] Script to search and match the first 5 bytes of a file to discover the real filetype on ubuntu
- [x] Windows Checklist
- [x] Windows scripts